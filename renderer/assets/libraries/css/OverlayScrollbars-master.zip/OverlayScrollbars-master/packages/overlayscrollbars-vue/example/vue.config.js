module.exports = {
	lintOnSave: false,
	publicPath: '/OverlayScrollbars/frameworks/vue/'
}
